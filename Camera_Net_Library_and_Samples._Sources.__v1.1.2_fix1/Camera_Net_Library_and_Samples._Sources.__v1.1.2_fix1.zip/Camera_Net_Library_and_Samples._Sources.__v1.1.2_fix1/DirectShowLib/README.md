Library **DirectShowLib** is not a part of Camera_Net library.

DirectShowLib is included in repo just to give an ability to build project/solution without any additional work.
